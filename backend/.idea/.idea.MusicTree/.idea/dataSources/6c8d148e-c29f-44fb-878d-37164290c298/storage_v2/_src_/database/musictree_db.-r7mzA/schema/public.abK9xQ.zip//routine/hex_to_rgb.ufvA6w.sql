create function hex_to_rgb(hex_color text)
    returns TABLE(r integer, g integer, b integer)
    language plpgsql
as
$$
BEGIN
    IF hex_color IS NULL OR LENGTH(hex_color) != 7 OR SUBSTR(hex_color, 1, 1) != '#' THEN
        RAISE EXCEPTION 'Invalid hex color format. Expected #RRGGBB';
END IF;
    
    r := ('x' || SUBSTR(hex_color, 2, 2))::bit(8)::int;
    g := ('x' || SUBSTR(hex_color, 4, 2))::bit(8)::int;
    b := ('x' || SUBSTR(hex_color, 6, 2))::bit(8)::int;
    
    RETURN NEXT;
END;
$$;

alter function hex_to_rgb(text) owner to musictree_admin;

