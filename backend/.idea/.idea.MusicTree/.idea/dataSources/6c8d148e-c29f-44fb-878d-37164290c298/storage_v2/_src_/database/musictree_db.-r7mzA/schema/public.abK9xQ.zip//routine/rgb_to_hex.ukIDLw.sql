create function rgb_to_hex(r integer, g integer, b integer) returns text
    language plpgsql
as
$$
BEGIN
    IF r IS NULL OR g IS NULL OR b IS NULL THEN
        RETURN NULL;
END IF;
    
    IF r < 0 OR r > 255 OR g < 0 OR g > 255 OR b < 0 OR b > 255 THEN
        RAISE EXCEPTION 'RGB values must be between 0 and 255';
END IF;

RETURN '#' || LPAD(TO_HEX(r), 2, '0') || LPAD(TO_HEX(g), 2, '0') || LPAD(TO_HEX(b), 2, '0');
END;
$$;

alter function rgb_to_hex(integer, integer, integer) owner to musictree_admin;

